import React from 'react';
import ReactDOM from 'react-dom';
import Pic from './Image/elon.jpg'
import Pic2 from './Image/mukesh.jpg'
import Card from './Card';
const App = () => {
   return(
    <div className='ui comments'>
        <Card name='Preeti'
        date='Today at 5:00 pm '
        text='It is a React Blog'
        picture={Pic} ></Card>

        <Card name='Laxmikant'
        date='Today at 6:00 pm '
        text='It is a Redux Blog'
        picture={Pic2} ></Card>
    </div>
   ) 
}

ReactDOM.render(
    <App></App>,
    document.querySelector('#root')
)